from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from flask_restful import Resource, Api
import datetime
from json import JSONEncoder


app = Flask(__name__)
api = Api(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
ma = Marshmallow(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(32), unique=True)
    email = db.Column(db.String(32), unique=True)
    # password = db.Column(db.String(32))
    # first_name = db.Column(db.String(32))
    # last_name = db.Column(db.String(32))
    # age = db.Column(db.Integer)

    def __init__(self, name, email):
        self.name = name
        self.email = email
class UserSchema(ma.Schema):
    class Meta: 
        fields = ('id', 'name', 'email')

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(32), unique=True)
    contact_person = db.Column(db.String(32), unique=True)
    created = datetime.datetime.now()

    def __init__(self, name, contact_person, created):
        self.name = name
        self.contact_person = contact_person
        self.created = created

class CustomerSchema(ma.Schema):
    class Meta: 
        fields = ('id', 'name', 'contact_person', 'created')

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.String(32), unique=True)
    customer = db.Column(db.String(32), unique=True)
    user = db.Column(db.String(32), unique=True)
    created = datetime.datetime.now()

    def __init__(self, name, contact_person, created):
        self.name = name
        self.contact_person = contact_person
        self.created = created

class MessageSchema(ma.Schema):
    class Meta: 
        fields = ('id', 'body', 'customer', 'created', 'user')

user_schema = UserSchema()
users_schema = UserSchema(many=True)
customer_schema = UserSchema()
customers_schema = UserSchema(many=True)
message_schema = UserSchema()
messages_schema = UserSchema(many=True)


class EndPoint_Users(Resource):

    @staticmethod
    def get():
        try: id = request.args['id']
        except Exception as _: id = None

        if not id:
            users = User.query.all()
            return jsonify(users_schema.dump(users))
        user = User.query.get(id)
        return jsonify(user_schema.dump(user))

    @staticmethod
    def post():
        name = request.json['name']
        email = request.json['email']
        user = User(name, email)
        db.session.add(user)
        db.session.commit()
        return jsonify({
            'Message': f'User {name} {email} inserted.'
        })

    @staticmethod
    def put():
        try: id = request.args['id']
        except Exception as _: id = None
        if not id:
            return jsonify({ 'Message': 'Must provide the user ID' })
        user = User.query.get(id)

        name = request.json['name']
        email = request.json['email']
        user.name = name 
        user.email = email 
        db.session.commit()
        return jsonify({
            'Message': f'User {name} {email} altered.'
        })

    @staticmethod
    def delete():
        try: id = request.args['id']
        except Exception as _: id = None
        if not id:
            return jsonify({ 'Message': 'Must provide the user ID' })
        user = User.query.get(id)

        db.session.delete(user)
        db.session.commit()

        return jsonify({
            'Message': f'User {str(id)} deleted.'
        })

class EndPoint_Messages(Resource):

    @staticmethod
    def get():
        try: id = request.args['id']
        except Exception as _: id = None

        if not id:
            messages = Message.query.all()
            return jsonify(messages_schema.dump(messages))
        message = Message.query.get(id)
        return jsonify(message_schema.dump(message))

    @staticmethod
    def post():
        body = request.json['body']
        customer = request.json['customer']
        created = datetime.datetime.now()
        message = Message(body, customer, created)
        db.session.add(message)
        db.session.commit()
        return jsonify({
            'Message': f'Message {body} {customer} {created} received.'
        })

    @staticmethod
    def sort_messages():
        try: id = request.args['id']
        except Exception as _: id = None
        if not id:
            return jsonify({ 'Message': 'Must provide the user ID' })
        message = Message.query.get(id)

        ##message sorting here 
        ## -- so the sorting stuff could totally rely on unique message indentifiers 


class EndPoint_Customers(Resource):

    @staticmethod
    def get():
        try: id = request.args['id']
        except Exception as _: id = None

        if not id:
            customer = Customer.query.all()
            return jsonify(users_schema.dump(users))
        customer = Customer.query.get(id)
        return jsonify(user_schema.dump(customer))


       ## fields = ('id', 'name', 'contact_person', 'created')
    @staticmethod
    def post():
        name = request.json['name']
        contact_person = request.json['contact_person']
        ## here a function to fetch users email for the underlying field -- running out of time
        email = ''
        created = datetime.datetime.now()
        customer = Customer(name, contact_person, created)
        db.session.add(customer)
        db.session.commit()
        return jsonify({
            'Message': f'Customer {name} {contact_person} {created} created.'
        })



api.add_resource(EndPoint_Users, '/api/users')
api.add_resource(EndPoint_Customers, '/api/users/customers')
api.add_resource(EndPoint_Messages, '/api/messages')

if __name__ == '__main__':
    app.run(debug=True)